﻿using Braintree;

namespace RockyProject.Utility.Braintree
{
    public interface IBrainTreeGate
    {
        IBraintreeGateway CreateGateway();
        IBraintreeGateway GetGateway();

    }
}
